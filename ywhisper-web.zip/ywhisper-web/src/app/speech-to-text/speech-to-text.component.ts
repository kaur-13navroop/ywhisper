import { Component, OnInit } from '@angular/core';
import { Hero } from '../hero';
import { WhisperYService } from '../whispery.service';
//import * as fs from 'fs';

@Component({
  selector: 'speech-to-text',
  templateUrl: './speech-to-text.component.html'
})
export class SpeechToTextComponent implements OnInit {
  
  constructor(private heroService: WhisperYService) { }

  ngOnInit() {
    this.getHelloWorld();
    this.sendSMS();
    this.playAudio();
  }

  playAudio(){
    let audio = new Audio();
    audio.src = "../../../assets/audio-file.flac";
    audio.load();
    audio.play();
    console.log(audio);
    var params = {
        objectMode: true,
        contentType: 'audio/flac',
        model: 'en-US_BroadbandModel',
        keywords: ['colorado', 'tornado', 'tornadoes'],
        keywordsThreshold: 0.5,
        maxAlternatives: 3,
        audio:audio.srcObject,
        api_key: "zV_FOj2hWamdd9QgZN8FCWF2uZGzhXLDhB9TYdDMcIb9"
    };
    this.heroService.postspeechtotext(params).subscribe(response => console.log(response));
    //this.heroService.speechtoText(audio.srcObject);
  }

  getHelloWorld(): void {
    this.heroService.getIBMHello()
      .subscribe(response => console.log("hello world", response));
  }

  sendSMS(): void {
    this.heroService.sendSMS()
      .subscribe(response => console.log("send sms", response));
  }
}
