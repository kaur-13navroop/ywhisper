import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of, onErrorResumeNext } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { Hero } from './hero';
import { MessageService } from './message.service';
import {webSocket, WebSocketSubject} from 'rxjs/webSocket';
// import {IamAuthenticator} from 'ibm-watson/auth';
// import * as SpeechToTextV1 from 'ibm-watson/speech-to-text/v1';
//import * as fs from 'fs';

declare var require: any;

@Injectable({ providedIn: 'root' })
export class WhisperYService {

  private heroesUrl = 'api/heroes';  // URL to web api

  private speechtotextUrl = 'https://api.eu-gb.speech-to-text.watson.cloud.ibm.com/instances/6fd32673-46aa-4e79-8417-c09aa775827d';
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'audio/flac', 'Access-Control-Allow-Origin':'true' })
  };
  myWebSocket: WebSocketSubject<any>;

  constructor(
    private http: HttpClient,
    private messageService: MessageService) { }

  getIBMHello(): Observable<any> {
    const url = "https://service.eu.apiconnect.ibmcloud.com/gws/apigateway/api/4c24cd4cbcbcd528aee2ee19a3ed87c89fce1e3712d4604df280efce2c8db351/hello";
    return this.http.get<any>(url).pipe(
      tap(_ => this.log(`called helloworld api`)),
      catchError(this.handleError<any>(`error occurred in helloworld api`))
    );
  }

  sendSMS(): Observable<any> {
    const url = "https://service.eu.apiconnect.ibmcloud.com/gws/apigateway/api/4c24cd4cbcbcd528aee2ee19a3ed87c89fce1e3712d4604df280efce2c8db351/sendsms";
    return this.http.get<any>(url).pipe(
      tap(_ => this.log(`called sendSMS api`)),
      catchError(this.handleError<any>(`error occurred in sendsms api`))
    );
  }

  speechtoText(audio: any) : void {
    var IAM_access_token = "eyJraWQiOiIyMDIwMDcyNDE4MzEiLCJhbGciOiJSUzI1NiJ9.eyJpYW1faWQiOiJpYW0tU2VydmljZUlkLTlkMDY0N2ZmLTg4YTAtNDM3My1iYWEzLTkyM2NkMTU1OTBiOCIsImlkIjoiaWFtLVNlcnZpY2VJZC05ZDA2NDdmZi04OGEwLTQzNzMtYmFhMy05MjNjZDE1NTkwYjgiLCJyZWFsbWlkIjoiaWFtIiwiaWRlbnRpZmllciI6IlNlcnZpY2VJZC05ZDA2NDdmZi04OGEwLTQzNzMtYmFhMy05MjNjZDE1NTkwYjgiLCJuYW1lIjoiMmJjMjI2ZjEtNGVjNS00OGExLThkNTgtMzM5ZWE3YjM3OGY4Iiwic3ViIjoiU2VydmljZUlkLTlkMDY0N2ZmLTg4YTAtNDM3My1iYWEzLTkyM2NkMTU1OTBiOCIsInN1Yl90eXBlIjoiU2VydmljZUlkIiwidW5pcXVlX2luc3RhbmNlX2NybnMiOlsiY3JuOnYxOmJsdWVtaXg6cHVibGljOnNwZWVjaC10by10ZXh0OmV1LWdiOmEvNTE1ODhlYTJlNzg0NGI5YTkxY2UwMDMwZmNlNzU2NzE6NmZkMzI2NzMtNDZhYS00ZTc5LTg0MTctYzA5YWE3NzU4MjdkOjoiXSwiYWNjb3VudCI6eyJ2YWxpZCI6dHJ1ZSwiYnNzIjoiNTE1ODhlYTJlNzg0NGI5YTkxY2UwMDMwZmNlNzU2NzEiLCJmcm96ZW4iOnRydWV9LCJpYXQiOjE1OTYyMTE5NjcsImV4cCI6MTU5NjIxNTU2NywiaXNzIjoiaHR0cHM6Ly9pYW0uY2xvdWQuaWJtLmNvbS9pZGVudGl0eSIsImdyYW50X3R5cGUiOiJ1cm46aWJtOnBhcmFtczpvYXV0aDpncmFudC10eXBlOmFwaWtleSIsInNjb3BlIjoiaWJtIG9wZW5pZCIsImNsaWVudF9pZCI6ImRlZmF1bHQiLCJhY3IiOjEsImFtciI6WyJwd2QiXX0.YKVZa40-q-sX8ckokIao7IMJ0H9IbYgPrP_HBYLQ2yE_eGtptS-Jwtiez9M2D62IcOyqm3OkRXq-iJ4q56Zlx7OTWcRTeP9uHRT3xWXO10Oj5WW9f-xzcIMIKCT5ayUWbJmeihgM5R7wBtM2cDInCJXgzz7YpjlmLyKHV0eyllDMfxjnyfjK1qrMEPu8zM8aRaU-Gw7Qnsj4aw9sj0R4UghUuZoZPSvUrw_bgyzY23cXUa8SZX-bwuj8obKdSpITX6GIxuBfzTZcsywRKa3iakwe4MwA-Y5XMizGPXjQHSQkFiMxKb3OQ8HSZvAUl9Z8tPGIqf-vWo7eCqFDIDwgYA";
    var wsURI = this.speechtotextUrl + '/v1/recognize' + '?access_token=' + IAM_access_token + '&model=en-US_BroadbandModel';
    this.myWebSocket = webSocket(wsURI);
    this.myWebSocket.next({
      'action': 'start',
      'content-type': 'audio/flac'
    });
    this.myWebSocket.next(audio);
    this.myWebSocket.next({'action': 'stop'});
    this.myWebSocket.subscribe(    
      msg => console.log('message received: ' + msg), 
      // Called whenever there is a message from the server    
      err => console.log('error', err), 
      // Called if WebSocket API signals some kind of error    
      () => console.log('complete') 
      // Called when connection is closed (for whatever reason)  
   );
  }  

  postspeechtotext(params: any): Observable<Hero> {
    return this.http.post<any>(this.speechtotextUrl, params, this.httpOptions).pipe(
      tap((newHero: any) =>{ console.log("response", newHero);}),
      catchError(this.handleError<any>('post speech to text error'))
    );
  }

  /** GET heroes from the server */
  getHeroes(): Observable<Hero[]> {
    return this.http.get<Hero[]>(this.heroesUrl)
      .pipe(
        tap(_ => this.log('fetched heroes')),
        catchError(this.handleError<Hero[]>('getHeroes', []))
      );
  }

  /** GET hero by id. Return `undefined` when id not found */
  getHeroNo404<Data>(id: number): Observable<Hero> {
    const url = `${this.heroesUrl}/?id=${id}`;
    return this.http.get<Hero[]>(url)
      .pipe(
        map(heroes => heroes[0]), // returns a {0|1} element array
        tap(h => {
          const outcome = h ? `fetched` : `did not find`;
          this.log(`${outcome} hero id=${id}`);
        }),
        catchError(this.handleError<Hero>(`getHero id=${id}`))
      );
  }

  /** GET hero by id. Will 404 if id not found */
  getHero(id: number): Observable<Hero> {
    const url = `${this.heroesUrl}/${id}`;
    return this.http.get<Hero>(url).pipe(
      tap(_ => this.log(`fetched hero id=${id}`)),
      catchError(this.handleError<Hero>(`getHero id=${id}`))
    );
  }

  /* GET heroes whose name contains search term */
  searchHeroes(term: string): Observable<Hero[]> {
    if (!term.trim()) {
      // if not search term, return empty hero array.
      return of([]);
    }
    return this.http.get<Hero[]>(`${this.heroesUrl}/?name=${term}`).pipe(
      tap(x => x.length ?
         this.log(`found heroes matching "${term}"`) :
         this.log(`no heroes matching "${term}"`)),
      catchError(this.handleError<Hero[]>('searchHeroes', []))
    );
  }

  //////// Save methods //////////

  /** POST: add a new hero to the server */
  addHero(hero: Hero): Observable<Hero> {
    return this.http.post<Hero>(this.heroesUrl, hero, this.httpOptions).pipe(
      tap((newHero: Hero) => this.log(`added hero w/ id=${newHero.id}`)),
      catchError(this.handleError<Hero>('addHero'))
    );
  }

  /** DELETE: delete the hero from the server */
  deleteHero(hero: Hero | number): Observable<Hero> {
    const id = typeof hero === 'number' ? hero : hero.id;
    const url = `${this.heroesUrl}/${id}`;

    return this.http.delete<Hero>(url, this.httpOptions).pipe(
      tap(_ => this.log(`deleted hero id=${id}`)),
      catchError(this.handleError<Hero>('deleteHero'))
    );
  }

  /** PUT: update the hero on the server */
  updateHero(hero: Hero): Observable<any> {
    return this.http.put(this.heroesUrl, hero, this.httpOptions).pipe(
      tap(_ => this.log(`updated hero id=${hero.id}`)),
      catchError(this.handleError<any>('updateHero'))
    );
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  /** Log a HeroService message with the MessageService */
  private log(message: string) {
    this.messageService.add(`HeroService: ${message}`);
  }
}
